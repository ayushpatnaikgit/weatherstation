import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_UP)
t = 0 
x = 0.0
t_end = time.time() + 10 
while time.time() < t_end:
    input_state = GPIO.input(18)
    if input_state == False:
        x = x + 1.0
	time.sleep(0.2)
print (x/5)
print (x)
