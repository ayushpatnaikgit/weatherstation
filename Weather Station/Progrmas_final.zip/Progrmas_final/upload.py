#program to upload data once internet comes back 
import datetime
import os;import Adafruit_DHT as dht 
import sys
import time
from urllib import urlencode
import urllib2
from sys import argv
target=open('log.txt','r+')
WU_URL = "http://rtupdate.wunderground.com/weatherstation/updateweatherstation.php"
def internet():
    try:
        urllib2.urlopen('http://216.58.192.142', timeout=1)
        return True
    except urllib2.URLError as err:
        return False
if internet() == False:
	exit()
def upload():
	csv_reader = csv.reader(open('log.txt'))
	for line in csv_reader:
		weather_data = {
                            "action": "updateraw",
                            "ID": "XXXXXXX",
                            "PASSWORD": "XXXXXX", #Get password and ID from wunderground
                            "dateutc": line[2],
                            "tempf": line[1],
                            "humidity": line[0],
                            "baromin": line[3],
                        }
                upload_url = WU_URL + "?" + urlencode(weather_data)
		response = urllib2.urlopen(upload_url)
		html = response.read()
		response.close()
target.truncate()
