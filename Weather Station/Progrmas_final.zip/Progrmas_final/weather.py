import Adafruit_DHT as dht 
h,t = dht.read_retry(dht.DHT22, 4)
print h,',',t

