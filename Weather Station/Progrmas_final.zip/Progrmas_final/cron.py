#! /usr/bin/python
import Adafruit_BMP.BMP085 as BMP085;import RPi.GPIO as GPIO
import os;import sys; import time; from urllib import urlencode
import urllib2; import datetime; import serial
import Adafruit_DHT as dht
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(24,GPIO.OUT)
GPIO.output(24,1)
GPIO.setup(23,GPIO.OUT)
GPIO.output(23,1)
 t = serial.Serial('/dev/ttyAMA0',9600)
t.setTimeout(1.5)

WU_URL = "http://rtupdate.wunderground.com/weatherstation/updateweatherstation.php"

def airquality(): 
    t = serial.Serial('/dev/ttyAMA0',9600)
    t.setTimeout(1.5)
    t.flushInput()
    time.sleep(0.5)
    retstr = t.read(10)
    if len(retstr)==10:
        if(retstr[0]==b"\xaa" and retstr[1]==b'\xc0'):
            checksum=0
            for i in range(6):
                checksum=checksum+ord(retstr[2+i])
            if checksum%256 == ord(retstr[8]):
                pm25=ord(retstr[2])+ord(retstr[3])*256
                pm10=ord(retstr[4])+ord(retstr[5])*256
                return pm25,pm10
def upload():
	h,t= dht.read_retry(dht.DHT22,4)
	float(t);float(h)
	sensor = BMP085.BMP085()
	temp = sensor.read_temperature();float(temp)
	pressure = sensor.read_pressure()
	float(pressure)
	pressure = str(pressure*0.000295301)
	T = (2*(t*1.8 + 32) + (temp*1.8+ 32)*0.5)/2.5
	try:
		pm25,pm10=airquality()
	except:
		exit()
	data = {
                            "action": "updateraw",
                            "ID": "XXXXXX",
                            "PASSWORD": "XXXXXX", #Get password and ID from wunderground
                            "dateutc": "now",
                            "tempf": str(T),
                            "humidity": str(h),
                            "baromin": pressure,
			   # "AqPM2.5":str(pm25),
			   # "AqPM10":str(pm10),
		}
	

	try:
                            upload_url = WU_URL + "?" + urlencode(data)
			    response = urllib2.urlopen(upload_url)
                            html = response.read()
                            response.close()  # best practice to close			    
	except:
			    logger =  str(h) + ',' + str(T) + ',' + str(datetime.datetime.utcnow())[:-7] +','+ str(pressure) +"\n"
			    target = open('log.txt','a')
			    target.write(logger) 
			    target.close()
upload()
GPIO.output(24,0)
GPIO.output(23,0)
GPIO.cleanup()
