# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO
from time import sleep
import serial
import time
import datetime  
GPIO.setwarnings(False);GPIO.setmode(GPIO.BCM)
GPIO.setup(24,GPIO.OUT)
GPIO.output(24,0)
t = serial.Serial('/dev/ttyAMA0',9600)  
time.sleep(5)
def read():

    t.flushInput()

    time.sleep(0.5)

    retstr = t.read(10)

    if len(retstr)==10:

        if(retstr[0]==b"\xaa" and retstr[1]==b'\xc0'):

            checksum=0

            for i in range(6):

                checksum=checksum+ord(retstr[2+i])

            if checksum%256 == ord(retstr[8]):

                pm25=ord(retstr[2])+ord(retstr[3])*256

                pm10=ord(retstr[4])+ord(retstr[5])*256
		a = str(datetime.datetime.now())
                print pm25/10.0,',',pm10/10.0,',',a

read()
GPIO.cleanup() 

 
